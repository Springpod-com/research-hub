# Replit handover prompt

Build on this supplied working application in a **new standalone Replit project**. Do not regenerate the frontend from scratch. Read `README.md`, `docs/PRD.md` and `docs/IMPLEMENTATION-STATUS.md` before changing anything. The status document is an implementation report, not a replacement for the PRD.

## Preserve these decisions

- Use Clerk and the intended organisational SSO connection. Do not replace it with custom magic-link authentication.
- Keep all access checks server-side. Only approved workspace members may access records, source files and packs.
- Keep the installed Springpod design system and the selectively reused starter components. Before UI changes, read `node_modules/@springpod/design-system/AGENTS.md` and `docs/npm-new-project.md` within that package. Keep `src/index.css` as the single Springpod import; import primitives, icons, `cn` and toasts from the package. Run `npx springpod-audit src`; it must exit 0.
- Do not connect to Employer Intelligence, import its backend, change its production app, use its database, or add cross-app synchronisation, full field catalogues, approval machinery or automated Studio delivery.
- Preserve stable IDs, evidence references, schema versions and immutable snapshots. Research readiness is not employer approval. Employer facts, occupational context, proposals and questions must remain distinct.

## First make the supplied app run

Install from the lockfile. Run the tests, typecheck, design audit and build. Use `npm run demo` only for a temporary fictional preview. Production must run `npm start` with real Clerk configuration and a new PostgreSQL database. The supplied `.replit` maps the production server to 5173; preserve a single public origin for frontend and API.

Create a fresh database dedicated to this project. Confirm its identity before setting `DATABASE_CONFIRMED_STANDALONE=true`. Configure secrets through Replit, never in committed files. Configure Clerk's actual SSO connection, domains and approved membership; adding keys alone is insufficient. Bootstrap one administrator, then remove the bootstrap setting after membership is recorded.

Configure exact model IDs available through the provider accounts. Do not guess API IDs from names such as Fable, GPT-6 or Codex identifiers. The Max path currently analyses shared captured sources independently with two models; preserve that truthful description unless two genuinely separate discovery runs are implemented and tested.

Provision file scanning compatible with `UPLOAD_SCAN_COMMAND`, or adapt to a supported hosted scanner with tests. Do not bypass the production scanner requirement.

## Close the documented PRD gaps

Use `docs/IMPLEMENTATION-STATUS.md` as the checklist. Prioritise official occupational dataset retrieval/matching, likely-match suggestions during organisation creation, explicit pack review state, and source-refresh/change visibility. Retain the existing usable manual paths. Confirm consequential product choices with the owner before expanding the MVP. Automated image interpretation and two independent web-discovery runs are optional extensions, not reasons to delay the core pilot.

For occupational data, preserve source identity, dataset version, code, rationale and jurisdiction. Never imply that O*NET describes the employer or is an automatic equivalent of a UK SOC code. If using imagery, distinguish visible observations from inferred procedures and retain usage permissions.

## Verify the deployed workflow

Test create organisation → define role → capture/upload evidence → run each configured research tier → inspect quotations and classifications → review findings and activities → answer/defer questions → create a draft and ready snapshot → download matching Markdown/JSON. Edit a source/profile and confirm earlier exports remain byte-stable. Check partial provider failure, invalid files, rejected origins, revoked members, unauthorised exports, keyboard use and mobile/tablet layouts.

Run a small synthetic live research job before real employer material. Check usage limits, provider access and failure reporting. Test Clerk against the actual identity provider with both approved and unapproved users. Configure backups and agree retention/erasure policy before launch.

Report the deployed URL, checks performed, remaining gaps and any external setup that requires the owner. Do not declare production readiness until live sign-in, data persistence, research and exports have been verified.
