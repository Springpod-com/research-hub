# Designer's note

_Springpod research · 2026-09-22_

The role folder gives strong professional standards and adjacent Marriott adverts. The exact Executive Sous Chef title and its boundaries at the learner’s hotel remain the main confirmation gap.
