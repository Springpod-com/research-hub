Title: Senior culinary chef — apprenticeship standard ST0864
Extracted from: https://skillsengland.education.gov.uk/apprenticeships/st0864-v1-0
Retrieved: 2026-09-22

# Senior culinary chef — apprenticeship standard ST0864

Source: Skills England / Institute for Apprenticeships and Technical Education
Address: https://skillsengland.education.gov.uk/apprenticeships/st0864-v1-0
Read: 2026-09-17 · Tier 3

- Reference: ST0864, version 1.0
- Level: 4
- Typical duration: 24 months
- Route: Catering and hospitality
- Approved for delivery: 25 February 2020
- Typical job titles: Chef patron, Craft chef, Culinary team leader, Development chef, Executive chef, Head chef
- External quality assurance: Ofqual

## Occupation summary (paraphrase of the standard)

The occupation develops new recipes, products and product lines across hospitality, aviation, care and hospital
sectors. Holders research and responsibly source ingredients, develop and launch products against a specification
brief aligned to the organisation's vision and values. Core responsibilities: maintaining culinary standards,
overseeing food preparation and presentation quality, managing food and supplies inventory, ensuring food safety
compliance, monitoring supplier performance, creating recipes from scratch or to brief, determining presentation
and packaging, maintaining profit margins and coordinating staff training. The role leads either as a sole-trader
patron's culinary inspiration or as leader of a culinary team producing for centralised distribution. Reports to a
restaurant patron or a senior leadership team.

## The twelve duties, as the standard states them

1. Identify opportunities to research, source and develop new culinary offers including recipes, products and product lines
2. Plan and develop the culinary offer according to organisational brief and communicate to the team
3. Source ingredients, equipment/technology, time and people to create the culinary offer
4. Order and maintain inventory of food and supplies
5. Follow the necessary legislation, regulations, guidance and organisational policies / procedures to produce the culinary offer
6. Ensure compliance with food safety management system when producing the culinary offer
7. Lead the team overseeing the preparation and presentation of quality food items
8. Present the culinary offer to stakeholders, for example teams, board, clients
9. Action feedback to refine the culinary offer developing contingency plans to enable the smooth introduction of the offer
10. Liaise with internal and external stakeholders to plan and launch of the culinary offer
11. Maintain, review and seek to continuously improve the current culinary offer, responding to sector trends and new ways of working to drive sales and profit
12. Commit to the development and continuous improvement of self and the teams involved in the creation of the culinary offer

## End-point assessment

Holistic or synoptic assessment of knowledge, skills and behaviours in an integrated way, assessing several KSBs
simultaneously. Described as "Rigorous robust and independent assessment undertaken by an apprentice at the end of
training to test competency in the occupation and demonstration of duties, KSBs set out in the occupational standard."

## Note for the pack

This is the closest English standard to Executive Sous Chef. The standard names Executive chef and Head chef as
typical job titles; it does not name Executive Sous Chef. Treat the mapping as our judgement, not the standard's.
