Title: Chef de partie — apprenticeship standard ST0227
Extracted from: https://skillsengland.education.gov.uk/apprenticeships/st0227-v1-1
Retrieved: 2026-09-22

# Chef de partie — apprenticeship standard ST0227

Source: Skills England / Institute for Apprenticeships and Technical Education
Address: https://skillsengland.education.gov.uk/apprenticeships/st0227-v1-1
Read: 2026-09-17 · Tier 3

- Reference: ST0227 (v1.1 read; latest version v1.2; v1.1 shown as retired)
- Level: 3
- Typical duration: 18 months
- Typical job titles: Chef de partie, Line chef, Section chef

## Occupation summary (paraphrase)

Runs a specific section of a professional kitchen — for example sauces, pastries or fish. Prepares and cooks complex
dishes, oversees the section, supervises team members and maintains hygiene and food safety standards. Contributes
to menu development, maximises yield and minimises waste.

## Core duties

1. Prepare dishes using advanced methods in line with brand standards
2. Cook dishes using advanced cooking methods
3. Finish dishes with advanced finishing techniques
4. Maximise yield and minimise waste in time-bound environments
5. Contribute to reviewing and refreshing menus
6. Oversee section staff in storing, preparing, cooking and finishing ingredients
7. Operate and oversee specialist kitchen equipment and technology
8. Coach and motivate team members positively
9. Liaise with internal/external stakeholders to build team relations
10. Improve competitiveness, business performance and customer experience
11. Monitor production per legislative regulations
12. Conduct risk assessments and ensure timely evaluation

The standard covers 35 knowledge areas, 16 skills and 8 behaviours.

## Why it is in this pack

Chef de partie is the rank the Executive Sous Chef develops and promotes from. It gives the vocabulary of the
brigade and the section structure the storyboard sits in.
