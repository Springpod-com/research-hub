Title: Craft Guild of Chefs — the professional body
Extracted from: https://craftguildofchefs.org/about-us
Retrieved: 2026-09-22

# Craft Guild of Chefs — the professional body

Source: Craft Guild of Chefs
Address: https://craftguildofchefs.org/about-us
Read: 2026-09-17 · Tier 3

- The UK's leading professional chefs' association; describes itself as "a body of professional Chefs committed to
  the advancement of useful knowledge and skills to support the industry and wider community"
- Founded 1885 as the Cookery and Food Association; became the Craft Guild of Chefs in 2003
- Over 1,200 members and 101 business partners, drawn from across foodservice "from students and trainees to top management"

## What it does

Raises professional cooking standards through education; develops members' careers; enhances culinary knowledge,
skills and abilities; runs craft skills competitions nationally and internationally (including National Chef of the
Year and graduate awards); advocates for recognition of the chef's profession; endorses British and European produce.
Also accredits colleges and training providers and runs product endorsement schemes.

## Note for the pack

There is no statutory register or protected title for chefs in the UK, and no chartered competence framework
equivalent to EngTech or RN. Membership grades are not published on the about page. The nearest things to a
competence framework for this role are the apprenticeship standards (ST0864, ST0227) and the employer's own brand
standards. The Institute of Hospitality is the other body commonly named for hospitality management.
