Title: Chef — National Careers Service job profile
Extracted from: https://nationalcareers.service.gov.uk/job-profiles/chef
Retrieved: 2026-09-22

# Chef — National Careers Service job profile

Source: National Careers Service (gov.uk)
Address: https://nationalcareers.service.gov.uk/job-profiles/chef
Read: 2026-09-17 · Tier 3

- Salary: £22,000 starter to £40,000 experienced
- Typical hours: 40 to 45 a week
- Working pattern: evenings, weekends and bank holidays, on shifts

## Entry routes

- University: culinary arts, professional cookery or related degrees
- College: hospitality, catering and professional cookery courses
- Apprenticeships: levels 2 to 4, including commis chef and pastry chef
- Work: on-the-job, starting as kitchen assistant or trainee

## Day-to-day duties, as the profile states them

- "develop recipes, plan menus and create new dishes"
- "prepare and cook dishes and desserts"
- "control stock and inspect deliveries"
- "maintain food safety and hygiene standards"
- "supervise kitchen staff to make sure food is of high quality, presented well and served on time"

## Skills

Knowledge of food production methods; "thorough" attention to detail; leadership and teamwork; ability to "accept
criticism and work well under pressure"; manual dexterity; time management; computer proficiency.

## Progression

Commis chef to sous chef to head chef. Senior chefs may move into restaurant or hospitality management, manage
multiple sites for chains, or set up independent catering businesses.

## Note

There is no separate National Careers Service profile for Sous Chef or Executive Sous Chef; the Chef profile is the
one that covers the family. The head-chef URL returns a 404 as at the read date.
