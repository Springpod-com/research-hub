Title: About
Extracted from: https://www.marriott.springpod.com/about?partner=centrepoint#
Retrieved: 2026-09-22

[](https://www.marriott.springpod.com/about?partner=centrepoint#)

## Discover your future with Marriott

At Marriott, your career is more than a job - it's a journey. A place to begin, belong, and become. With opportunities worldwide, you can belong to a welcoming community, become the person you’re meant to be, and be inspired by what’s possible.

At Marriott, the only limit is your imagination. Be boundless. Be ambitious. Be you.

![Marriott employee smiling whilst organising hotel room](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b061683889a74f10933ffb_Marriott-room-service-hero.webp)

## Begin your career journey at Marriott

As the #1 leader in hospitality worldwide, Marriott International has 9,600+ hotels — and we’re still growing. From luxury to lifestyle, resorts to city stays - our 39+ brands span the globe and offer something for everyone.

Whether you're curious about your first job or dreaming big, this is your chance to explore what a career in hospitality could look like.

[![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689f12837aca93793f5fb74a_video-play.svg)![Two male Marriott bartenders thoughtfully mixing cocktails. ](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b0616881e8dcd73529afce_Marriott-bar-tenders-hero.webp)](https://www.marriott.springpod.com/about?partner=centrepoint#)

![Belong. Belong. Become.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689f128301bda8362c358afd_Begin-belong-become.svg)

### About Marriott

#### What we do

Marriott is one of the world’s leading hospitality companies, with thousands of hotels across more than 130 countries. We create welcoming spaces, unforgettable stays, and career opportunities that span the globe.

[

Marriott Careers

![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689b50b78a0a454c843646fb_small.svg)](https://careers.marriott.com/jobs?location_name=United%20Kingdom&location_type=4?lang=en-us&utm_source=Springpod&utm_medium=jobshare)

![Marriott employee making hotel room bed](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19aeaee5e7313501640a7_housekeeping-service-1.webp)

![Two male chefs preparing food in a professional kitchen. ](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19ae981333a4c6ad8269e_two-chefs-working.webp)

#### How we do it

Hospitality is about people. At Marriott, teamwork, respect, and opportunity are at the heart of everything we do. Our culture celebrates diversity and empowers everyone to grow, learn, and succeed.

[

Marriott Careers

![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689b50b78a0a454c843646fb_small.svg)](https://careers.marriott.com/jobs?location_name=United%20Kingdom&location_type=4?lang=en-us&utm_source=Springpod&utm_medium=jobshare)

#### Where we do it

From city centres to beach resorts, from small towns to global capitals — you’ll find Marriott hotels in destinations around the world. Wherever your career takes you, there’s a place for you with Marriott.

[

Marriott Careers

![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689b50b78a0a454c843646fb_small.svg)](https://careers.marriott.com/jobs?location_name=United%20Kingdom&location_type=4?lang=en-us&utm_source=Springpod&utm_medium=jobshare)

![Male bartender serving a drink and smiling.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19ae972778cbaad97b40b_man-serving-drink-at-bar.webp)

###### About this exciting partnership

![Be Marriott Bonvoy](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689b4b142851fe818505e862_be-logo.svg)![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de6b8e1cc98e48ac831f9_Accenture.svg)![Movement to Work](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de6be0f634cfe75a47453_Movement-to-work-logo.png)![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de717bd27fd260b3c91ca_Springpod-logo.svg)

This programme is brought to you by Marriott International, in partnership with Accenture and Movement to Work. Together, we’re creating new ways for young people in the UK to discover careers in hospitality and take their first steps into work.

By combining Marriott’s global opportunities and industry expertise, Accenture’s skills development expertise, and Movement to Work’s mission to support young people into employment, this virtual learning experience opens the door to a brighter future for everyone.

![Movement to Work](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de6be0f634cfe75a47453_Movement-to-work-logo.png)

##### About Movement to Work

Movement to Work operates in a world of opportunity and seeks to break the vicious ‘no experience – no job’ cycle that is preventing young people, not currently in education, employment or training, from stepping onto the career ladder.

By supporting organisations in providing quality vocational employment and work placement opportunities, Movement to Work helps to drive both business performance and bring about lasting social change.

[

Learn more

](https://movementtowork.com/)

![Female Marriott employee smiling.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b199596966042f57587af2_MTW-background.webp)