Title: Marriott International — Wikipedia
Extracted from: https://en.wikipedia.org/wiki/Marriott_International
Retrieved: 2026-09-22

# Marriott International — Wikipedia

Source: Wikipedia, "Marriott International"
Address: https://en.wikipedia.org/wiki/Marriott_International
Read: 2026-09-17 · Tier 3 (encyclopaedia, not the employer's own material)

- Founded 1927 by John Willard Marriott and Alice Marriott, as a root beer stand in Washington, DC
- Headquarters: Bethesda, Maryland
- Incorporated in Delaware; Nasdaq: MAR (Class A); S&P 500 constituent
- Employees: **418,000 (2024)**
- Brands: **41**, as of 2025
- CEO: Anthony Capuano, appointed February 2021
- Portfolio as stated there: 9,361 properties, 1,706,331 rooms, 144 countries and territories (2025)

## Milestones

- 1927 — root beer stand opens
- 1957 — first hotel, the Marriott Motor Hotel, Arlington, Virginia
- 1993 — Marriott Corporation splits into Marriott International (franchising and management) and Host Marriott (property ownership)
- 2016 — completes the **$13.6 billion** acquisition of Starwood Hotels, creating the world's largest hotel company

## The entity question

The learner meets **Marriott International, Inc.** — the manager and franchisor — not a property owner. A UK hotel a
learner might name (London Marriott Hotel Park Lane, Courtyard by Marriott Sandy Park, The St. Regis London) is one
of forty-plus brands in that portfolio and may be managed or franchised. The 1993 split is why "Marriott" the
operator and "Marriott" the building are not the same company. Worth one plain sentence in the chapter; worth
checking with the client which entity employs the Executive Sous Chef in the hotel we set the chapter in.
