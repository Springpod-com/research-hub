Title: Our-Story
Extracted from: https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-First-Hot-Shoppe-1927-167891250236644.jpg.transform/mcom-hp-transform-430x242/image.jpg
Retrieved: 2026-09-22

At Marriott, we never stop searching for inventive ways to serve our customers, provide opportunities for our associates, and grow our business. The company that began as a nine-seat A&W root beer stand is recognized today as a top employer and for its superior business operations, which it conducts based on five core values: put people first, pursue excellence, embrace change, act with integrity, and serve our world.

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-First-Hot-Shoppe-1927-167891250236644.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1927
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-GeorgiaAve-First-Drive-in-167891248703278.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1928
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_core-values-heritage/unlimited/photo/assets/pdt-JWM-Sr-Alice-201941988660-806759314272412.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1929
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-HS008-545561047610111-167765176056341.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1937
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-US-Treasury-Cafeteria-167891233619283.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1940-1950
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-1956-281097762271435-167765184086058.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1953
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-pdt-MightyMoHamburg-40980-167759580659210.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1955
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-770835562386655.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1955
    

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-First-hotel-Twin-Bridges-167891199856811.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1957
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Key-Bridge-ribbon-cutting-167891245905553.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1959
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Venezuela-In-Flite-Jan196-167891244513984.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1966
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_core-values-heritage/unlimited/photo/assets/pdt-Marriott-Corp-crown252365-861163551793114.png.transform/mcom-hp-transform-430x242/image.png)
    
    ### 1967
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Roy-Rogers-opening-167891242635954.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1968
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-138859150050497.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1969
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-836902405259654.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1975
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Great-America-Gurnee-167891237538194.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1976
    

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-452947896331092.jpeg.transform/mcom-hp-transform-430x242/image.jpeg)
    
    ### 1979
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-753806048753962.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1981
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-JWM-Jr-outside-Courtyard-167891171313083.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1983
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-242810402038267.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1984
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-929977305623231.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1984
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-996736540647305.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1987
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-616869054658425.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1987
    

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-split-stoc535319734851648-1677654267796-0.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1993
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Ritz-Carlton-Signage54283-167768208670391.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1995
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-TownePlace-Suites-sign-608130070595903.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1997
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-590377220927933.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1997
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-812751417655411.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1998
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-879596115753495.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 1999
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/rz/us-canada/hws/w/wasrt/en_us/logo/third-party/assets/rcwashi_00064_conversion.png.transform/mcom-hp-transform-430x242/image.png)
    
    ### 2000
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Bvlgari-Bulgari-ca-454925483808052.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2004
    

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Autograph-Cosmopolitan-248053957308208.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2009
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Hotel-Mala151201114914713-167753494204668.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2011
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Arne-Sorenson-and-JWM-Jr--241756636189781.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2012
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-380542586850678.JPG.transform/mcom-hp-transform-430x242/image.JPG)
    
    ### 2012
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Moxy-Mila584791635242075-1677535366443-6.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2013
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Protea-108055137906981-167753507631940.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2014
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-delta-hote940749539665383-167765115287654.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2015
    

-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-670744206478935.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2016
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-MarriottHQ-99865831148711-167752690731222.JPG.transform/mcom-hp-transform-430x242/image.JPG)
    
    ### 2018
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Bonvoy-logo-from-MAL31680-1677687728119-0.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2019
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-Capuano-728541948182015-167752696138720.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2021
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/digitallegal-micorp-cec/en_us/micorp_about-marriott/unlimited/photo/assets/pdt-HQ-lob402015714766826-167765197162443.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2022
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/lc/us-canada/hws/l/lasbl/en_us/photo/unlimited/assets/lc-lasbl-bellagio-hero-54904.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2023
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/xe/global-property-shared/fr_fr/photo/09-2018-photoshoot/unlimited/assets/xe-xe-qroxj-qroxj-exterior-9-11186.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2023
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/rs/global-property-shared/en_us/rendering/other/unlimited/assets/rs-exterior-rendering-31740.jpg.transform/mcom-hp-transform-430x242/image.jpg)
    
    ### 2024
    
-   ![image](https://www.marriott.com/content/dam/marriott-digital/cm/us-canada/hws/s/sfopk/en_us/photo/unlimited/assets/cm-sfopk-080f1dd3d7a24b8b83a5b828338e8f40.tif.transform/mcom-hp-transform-430x242/image.tif)
    
    ### 2025