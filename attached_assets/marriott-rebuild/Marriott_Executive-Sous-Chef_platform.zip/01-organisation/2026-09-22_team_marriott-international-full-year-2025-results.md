Title: Marriott International — full year 2025 results
Extracted from: https://marriott.gcs-web.com/news-releases/news-release-details/marriott-international-reports-fourth-quarter-and-full-year-2025
Retrieved: 2026-09-22

# Marriott International — full year 2025 results

Source: Marriott International investor relations, "Marriott International Reports Fourth Quarter and Full Year 2025 Results", released 10 February 2026
Address: https://marriott.gcs-web.com/news-releases/news-release-details/marriott-international-reports-fourth-quarter-and-full-year-2025
Read: 2026-09-17 · Tier 2

- Properties: **over 9,800**, as of 31 December 2025
- Rooms: **nearly 1,780,000**
- Countries and territories: **145**
- Full-year 2025 total revenues: **$26,186 million**
- Full-year 2025 net income: **$2,601 million**
- Listed: Nasdaq: MAR · headquartered Bethesda, Maryland, USA

## The company's own boilerplate, verbatim

"Marriott International, Inc. (Nasdaq: MAR) is based in Bethesda, Maryland, USA, and encompasses a portfolio of
compelling brands across luxury, premium, select, midscale, extended stay, and all-inclusive, with over 9,800
properties in 145 countries and territories, as of December 31, 2025. Marriott franchises, operates, and licenses
hotel, residential, timeshare, yacht, outdoor, and other lodging products all around the world. The company offers
Marriott Bonvoy, its highly awarded travel platform."

## Conflict to resolve before use

The Springpod-hosted Marriott pages in this folder say "9,600+ hotels" and "39+ brands"; the Marriott careers Early
Careers page says "9000+ hotels", "30+ brands", "140+ countries". This release says over 9,800 properties in 145
countries. Wikipedia says 9,361 properties in 144 countries and 41 brands as of 2025. **Use this release's figures
and cite them as at 31 December 2025.** Do not mix the numbers from different pages in one sentence.
