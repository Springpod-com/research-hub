Title: Marriott
Extracted from: https://www.marriott.springpod.com/?partner=centrepoint#
Retrieved: 2026-09-22

[](https://www.marriott.springpod.com/?partner=centrepoint#)

Hospitality isn’t just about hotels – it’s about people, opportunities, and building a future you can be proud of. With Marriott, you’ll get a taste of real careers, discover skills you already have, and explore where hospitality could take you.

![Marriot employees smiling at a team meeting.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b0616818c80b507dbfb079_Marriott-team-hero.webp)

## A groundbreaking project to unearth the future of hospitality

Be Inspired

Hospitality is full of opportunity - and we want more people to see what it's like.

Marriott International and Movement to Work have created these courses in the UK to open the doors wide, giving you a free, accessible way to explore the industry, try out different roles, and build confidence in your skills.

![Marriott employee smiling whilst interacting with customer.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b1890c658b539b89911b9c_front-of-house-square-2.webp)

Be Curious

Virtual Work Experience

A virtual work experience is a free online programme that lets you test drive a career. In just a few hours, you’ll explore real jobs in hospitality, take part in interactive activities, and build the skills that employers value. You’ll also earn a certificate you can add to your CV or LinkedIn, helping you feel more confident about your next step.

![Female bartender smiling whilst making a cocktail. ](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19ae9658b539b89979f8e_female-cocktail-barstaff.webp)

Be Ready

At Marriott, you can be a part of something bigger than yourself, be inspired by what’s possible, and discover your own future.

Each of these Experiences is free and flexible. You can learn at your own pace, from anywhere.

Along the way, you’ll build real-world skills employers look for, like teamwork, communication, and problem-solving.

This is your chance to take the first step - toward a job, a career, and a future in hospitality.

![Female Marriott employee smiling, pictured outside amongst greenery.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19aeae3d768af08fa11b5_smiling-female-member-of-staff.webp)

**Be Confident**

These experiences are designed to give you more than information – they give you a space to learn and grow without the pressure. By the end, you’ll:

-   Understand what different hospitality careers actually involve.
-   Recognise which roles and skills feel right for you.
-   Know the next steps you can take, from further training to applying for jobs.

Confidence built. Choices made. Future unlocked.

![Professionally dressed Marriott employee smiling.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b19aea0465967ba7c64d6c_concierge-waiting-for-guests.webp)

### An opportunity for a new career is at your fingertips

Marriott, in association with Accenture and Movement to Work, has created a new way for you to explore hospitality careers. Try our free virtual experiences and see if hospitality could be your future.

Step 1

Be Curious. Find an experience that interests you

Choose from a range of free online experiences designed to show you what hospitality is really about.

Step 2

Be Ready. Sign up for your free Springpod account

It takes two minutes – it's as simple as that. Create your free Springpod account and get instant access — there are no hidden costs or long forms.

Step 3

Be Involved. Complete a virtual learning experience

Take part in interactive activities, explore real Marriott careers, and build new skills at your own pace.

Step 4

Be Ambitious. Use your new skills to apply for a job

Use your new confidence and certificate to apply for jobs, boost your CV.

#### Get an overview of a career in hospitality

#### And, get a taster for the following careers

![](https://cdn.prod.website-files.com/689ee83fadb61c7f177c7377/68b186750bace6542d34e517_food-drink-square-2.webp)

1 hour

Food & Drink

Step into the world of food and beverage with Marriott. From preparing dishes to designing memorable dining experiences, you’ll learn how creativity and teamwork come together in this part of hospitality.

![](https://cdn.prod.website-files.com/689ee83fadb61c7f177c7377/68b186e0148aa148126a1145_front-of-house-square-1.webp)

1 hour

Front of House

At Marriott, front of house is all about people. Explore what it’s like to greet guests, solve problems, and make every visitor feel at home.

##### What is a virtual learning experience?

A virtual learning experience is a free online programme that lets you test drive a career.

You’ll explore real jobs in hospitality, take part in interactive activities, and build the skills that employers value. You’ll also earn a certificate you can add to your CV or LinkedIn, helping you feel more confident about your next step.

Interactive online learning

These experiences provide an engaging platform for you to explore different industries and careers from the comfort of your own home.

Practical skills development

You will complete real-world tasks and projects designed with top employers, helping you gain practical insights and workplace skills.

Flexible and accessible

The experiences can be completed at your own pace, in your own time, and often include live talks or webinars with industry professionals.

![Two Marriott employees smiling at one another and making hotel room bed.](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/68b1890db6912c2fd8d283a1_hospitality-square-1.webp)

###### About this exciting partnership

![Be Marriott Bonvoy](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689b4b142851fe818505e862_be-logo.svg)![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de6b8e1cc98e48ac831f9_Accenture.svg)![Movement to Work](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de6be0f634cfe75a47453_Movement-to-work-logo.png)![](https://cdn.prod.website-files.com/689b19a63ca6126cbe9d93be/689de717bd27fd260b3c91ca_Springpod-logo.svg)

This programme is brought to you by Marriott International, in partnership with Accenture and Movement to Work. Together, we’re creating new ways for young people in the UK to discover careers in hospitality and take their first steps into work.

By combining Marriott’s global opportunities and industry expertise, Accenture’s skills development expertise, and Movement to Work’s mission to support young people into employment, this virtual learning experience opens the door to a brighter future for everyone.