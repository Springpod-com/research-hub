# Designer's note

_Springpod research · 2026-09-22_

The organisation folder is strongest on Marriott’s public scale, story and values. It is thinnest on the exact UK hotel entity and property ownership context, which should be confirmed before storyboard wording is fixed.
