Title: Marriott-is-Growing-Forward-—
Extracted from: Team folder 01-employer/Marriott-is-Growing-Forward-—.md
Retrieved: 2026-09-22

This principle drives every aspect of the company’s operations and strategic goals. To achieve these objectives, Marriott is focusing on three critical paths:

**1\. Brands and experiences**

Marriott is dedicated to continually enhancing its portfolio of brands, ensuring each one offers unique and exceptional experiences that resonate deeply with guests. This includes innovative design, top-notch service, and offerings that cater to various traveler preferences.

**2\. Loyal members**

Fostering loyalty is a cornerstone of Marriott’s strategy. Through the Marriott Bonvoy program, the company provides rewards and personalized experiences, aiming to build lasting relationships with its members.

**3\. Be in more places**

Expanding its global footprint is a key priority. Marriott is committed to increasing its presence in both established and emerging markets, making its world-class hospitality accessible to more travellers around the globe.

“Our Growing Forward strategy creates the road map for how Marriott will lead the industry and be the first choice for associates, customers, and owners and franchisees,” said Kristen Fuller, Senior Director - Global Sales Organization, Marriott International. “We want to make sure our Marriott Bonvoy members, guests, owners and franchisees, and the broader travel community understand our priorities as we deliver on the promise of Marriott’s unique brand of hospitality around the world.”

To reach these goals, Marriott is relying on four key pillars: talent, digital transformation, sustainability and risk management.

**Talent**: Recognizing that its employees are its greatest asset, Marriott invests heavily in attracting, retaining, and developing top talent. This focus on human capital drives innovation and ensures the delivery of exceptional guest experiences.

**Digital transformation**: In the digital age, leveraging technology is crucial. Marriott is committed to digital transformation to enhance operational efficiency, improve guest interactions, and provide seamless experiences across all touchpoints.

**Sustainability**: Environmental stewardship is at the core of Marriott’s values. The company is dedicated to sustainable practices that reduce its carbon footprint and promote responsible travel, meeting the growing demand for eco-friendly options.

**Risk management**: Proactive risk management is essential for navigating uncertainties and maintaining resilience. Marriott implements robust frameworks to protect its assets and stakeholders, ensuring long-term stability and success.

**Growing forward in action**

A recent example of Marriott’s strategy in action can be seen in Canada, where the company is responding to increased leisure demand. By enhancing brand offerings, expanding the Marriott Bonvoy program, and increasing its property footprint, Marriott is making significant strides in aligning with its Growing Forward strategy.

“I am thrilled about our expanding presence in Canada, with new openings and localized Marriott Bonvoy partnerships and programming that offer something for everyone,” said Fuller.