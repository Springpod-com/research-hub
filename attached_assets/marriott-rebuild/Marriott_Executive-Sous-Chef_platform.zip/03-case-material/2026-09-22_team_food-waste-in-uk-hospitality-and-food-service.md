Title: Food waste in UK hospitality and food service
Extracted from: https://www.wrap.ngo/content/overview-waste-hospitality-and-food-service-sector
Retrieved: 2026-09-22

# Food waste in UK hospitality and food service

Source: WRAP, "Overview of waste in the hospitality and food service sector"
Address: https://www.wrap.ngo/content/overview-waste-hospitality-and-food-service-sector
Read: 2026-09-17 · Tier 3

- "920,000 tonnes of food is wasted at outlets each year"
- Where it arises: **45% from food preparation**, **34% from consumer plates**, **21% from spoilage**
- Cost: "£2.5 billion per year in 2011"

**Date caution.** The cost figure is explicitly 2011 and the tonnage appears to come from the same study. It is old.
If the chapter puts a number on food waste, either say "WRAP, 2011" on the face of it or find a current figure before
the storyboard is written. WRAP's Guardians of Grub campaign (https://guardiansofgrub.com/) is the current
hospitality-facing programme and is the place to look for a newer figure.

## Why it matters to the chapter

The 45% preparation share is the number that makes the over-ordering scenario a kitchen problem rather than a
purchasing problem: most of the waste is created between the walk-in and the pass, which is exactly the ground the
Executive Sous Chef owns.
