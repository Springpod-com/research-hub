Title: Food Hygiene Rating Scheme — what an inspection actually looks at
Extracted from: https://www.gov.uk/government/publications/food-hygiene-rating-scheme/food-hygiene-rating-scheme
Retrieved: 2026-09-22

# Food Hygiene Rating Scheme — what an inspection actually looks at

Source: Food Standards Agency / GOV.UK
Address: https://www.gov.uk/government/publications/food-hygiene-rating-scheme/food-hygiene-rating-scheme
Read: 2026-09-17 · Tier 3

Operated by the FSA in partnership with local authorities in England, Wales and Northern Ireland.

## The scale

- **5** — "hygiene standards are very good"
- **4** — "hygiene standards are good"
- **3** — "hygiene standards are generally satisfactory"
- **2** — "some improvement is necessary"
- **1** — "major improvement is necessary"
- **0** — "urgent improvement is required"

## The three elements a food safety officer assesses

1. "how hygienically the food is handled – how it is prepared, cooked, re-heated, cooled and stored"
2. "the physical condition of the business – including cleanliness, layout, lighting, ventilation, pest control and other facilities"
3. "how the business manages ways of keeping food safe, looking at processes, training and systems to ensure good hygiene is maintained"

## Who and how often

"A food safety officer from the local authority inspects a business to check that it follows food hygiene law so
that the food is safe to eat." Ratings are displayed at the premises and online; display is voluntary in England,
required in Wales and Northern Ireland. "Local authorities upload ratings at least every 28 days."

## Why it matters to the chapter

Element 3 is the one that turns a missing temperature log into a scoring problem, not just a paperwork problem.
That is the mechanism behind the "inspection announced for tomorrow, logs not completed for four days" scenario in
the simulation script: the records are the evidence of the management system.
