Title: The 14 regulated allergens
Extracted from: https://www.gov.uk/government/publications/allergen-guidance-for-food-businesses
Retrieved: 2026-09-22

# The 14 regulated allergens

Sources: Food Standards Agency, "Allergen guidance for food businesses" (published 2 April 2020, last updated
17 July 2026) — https://www.gov.uk/government/publications/allergen-guidance-for-food-businesses ;
Allergy UK, "Top 14" — https://www.allergyuk.org/types-of-allergies/food-allergy/top-14/
Read: 2026-09-17 · Tier 3

## The fourteen, as named in UK law

1. Celery
2. Cereals containing gluten (wheat, barley, oats)
3. Crustaceans (prawns, crab, lobster)
4. Eggs
5. Fish
6. Lupin
7. Milk
8. Molluscs (mussels, oysters)
9. Mustard
10. Peanuts
11. Sesame
12. Soybeans
13. Sulphur dioxide and sulphites (above 10 ppm)
14. Tree nuts (almonds, hazelnuts, walnuts, Brazil nuts, cashews, pecans, pistachios, macadamia nuts)

Allergy UK states: "By law, the 14 regulated allergens must be declared on food packaging and communicated clearly
for all food sold, including loose and non-prepacked foods."

## Gap — to verify before the storyboard states it

The FSA landing page did not render the regulation name or the PPDS ("Natasha's Law") detail on the read date.
Before the chapter states a legal citation, open the FSA HTML guidance itself and record: the regulation name and
number, the PPDS labelling requirement and its commencement date, and the FSA's wording on cross-contamination.
Do not let the chapter cite a regulation this pack has not read.

## Why it matters to the chapter

The simulation script opens with a dietary change for three hundred covers, two days out, with the Executive Chef
unreachable. Allergen information is the part of that decision that is not negotiable and not delegable to the
events team. It is the cleanest "what matters first" in the whole role.
