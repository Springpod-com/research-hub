**LONDON MARRIOTT HOTEL PARK LANE – WHERE BOUTIQUE SERVICE BEGINS ON PARK LANE**

Experience unmatched sophistication in Mayfair at London Marriott Hotel Park Lane. Perfectly placed in the city centre, our 5-star hotel welcomes you with bespoke luxury amenities and close proximity to some of London's most famous attractions. Intuitively designed accommodation is infused with boutique-inspired touches and offers plush bedding, marble bathrooms and 24-hour room service. Some rooms showcase breath-taking views of Hyde Park. Settle in for a meal, Afternoon Tea or evening cocktails at Lanes of London, or maintain your health at The Club at Park Lane, our fitness centre featuring an indoor pool, steam rooms, massage services and a modern gym. Our light-filled venues, superior planning and world-class catering services make us a superb choice for hosting impressive business meetings, social events and more. When it's time to explore London, you'll find the best of the city lies just beyond our hotel doors - from Hyde Park and Oxford Street to Marble Arch. We are part of Marriott International, the world's leading, award winning, hospitality company with more than 7,000 properties across 130 countries and territories worldwide. Begin your career journey with Marriott. Your 5-star experience awaits. 

We are now recruiting for an experienced **Junior Sous Chef** to join our five-star, luxurious boutique hotel. Have fun working alongside a fantastic team and enjoy a world where career progression opportunities and world class training is available to you. We enjoy crafting bespoke experiences for you. 

**ARE YOU ELIGIBLE TO WORK IN THE UK?**

A points-based immigration system affecting the eligibility to apply to work in the UK has been introduced from 01 January 2022. Applicants with Irish citizenship, an indefinite leave to enter the UK or an indefinite leave to remain in the UK are eligible to work in the UK including EU citizens who already lived in the UK by 31 December 2020. Please refer to the Home Office website for more details. You can also prove your right to work to employers by visiting the GOV UK website. 

**JOB SUMMARY** 

Entry level management position that focuses on successfully accomplishing the daily objectives in the kitchen.  Assists in leading staff while personally assisting in all areas of the kitchen, including food production; purchasing and kitchen sanitation. Position contributes to ensuring guest and employee satisfaction while maintaining the operating budget. 

**SKILLS, EXPERIENCE AND QUALIFICATIONS**

Education and Experience

-   High school diploma or GED; 4 years experience in the culinary, food and beverage, or related professional area.

OR

-   2-year degree from an accredited university in Culinary Arts, Hotel and Restaurant Management, or related major; 2 years experience in the culinary, food and beverage, or related professional area.

**CORE WORK ACTIVITIES** 

**Ensuring Culinary Standards and Responsibilities are Met**

-   Maintains food handling and sanitation standards.
-   Performs all duties of Culinary and related kitchen area employees in high demand times.
-   Oversees production and preparation of culinary items.
-   Ensures employees keep their work areas clean and sanitary.
-   Works with Restaurant and Banquet departments to coordinate service and timing of events and meals.
-   Complies with loss prevention policies and procedures.
-   Strives to improve service performance.
-   Communicates areas in need of attention to staff and follows up to ensure follow through.
-   Leads shifts while personally preparing food items and executing requests based on required specifications.
-   Prepares and cooks foods of all types, either on a regular basis or for special guests or functions.
-   Supervises and coordinates activities of cooks and workers engaged in food preparation.
-   Checks the quality of raw and cooked food products to ensure that standards are met.
-   Assists in determining how food should be presented and creates decorative food displays.

**Supporting Culinary Team Activities**

-   Supervises daily shift operations.
-   Ensures all employees have proper supplies, equipment and uniforms.
-   Supervises staffing levels to ensure that guest service, operational needs and financial objectives are met.
-   Ensures completion of assigned duties.
-   Participates in the employee performance appraisal process, giving feedback as needed.
-   Handles employee questions and concerns.
-   Communicates performance expectations in accordance with job descriptions for each position.
-   Participates in an on-going employee recognition program.
-   Conducts training when appropriate.
-   Monitors employee's progress towards meeting performance expectations.

**Maintaining Culinary Goals**

-   Participates in department meetings and continually communicates a clear and consistent message regarding the departmental goals to produce desired results.
-   Supports and assists with new menus, concepts and promotions for the Restaurant outlets and Banquets.

**Providing Exceptional Customer Service**

-   Sets a positive example for guest relations.
-   Handles guest problems and complaints seeking assistance from supervisor as necessary.
-   Empowers employees to provide excellent customer service within guidelines.

**Additional Responsibilities**

-   Reports malfunctions in department equipment.
-   Purchases appropriate supplies and manages food and supply inventories according to budget.

Attends and participates in all pertinent meetings

**WHAT WE CAN OFFER YOU**

**Proudly ranked among the Top 5 Hotels in London in the Condé Nast Readers’ Choice Awards 2025**

A unique opportunity to be part of an award-winning international brand where we celebrate your unique talent. Being part of Marriott International, the largest hospitality brand in the world opens doors of opportunity worldwide. The sky is your limit. You will have access to fabulous & flexible benefits to help you nurture your inner self.

**<u>FINANCIAL WELLNESS</u>**

-   Competitive salary package
-   28 days holiday including bank holidays increasing to a maximum of 35 days
-   Accommodation Service Charge upon successful completion of probation
-   Season ticket loans
-   Discounted room rates for you & friends and family - why not, we are after all the largest hotel company in the world!
-   Discount in Lanes of London
-   Recommend a friend scheme
-   Complimentary dry cleaning - we do like to make an impression!
-   Competitive car lease schemes
-   Access to major high street discounts so you can treat your friends and family 
-   World-class international career opportunities within Marriott hotels tailored to your specific needs
-   Professional learning and development opportunities - because a fulfilling career is so much more rewarding
-   Tuition aid
-   Unlock access to world-class trainers and elevate your potential
-   Exclusive access to the world’s leading management minds
-   Complimentary meals on duty 
-   Eye care vouchers
-   Cycle to work scheme
-   Creative workshops
-   Support volunteer programmes like Magic Breakfast
-   Community activities like canal cleaning, volunteering at farms, plogging and much more
-   Plant a tree
-   Annual parties, Christmas lunches, summer BBQ's and Easter celebrations
-   Length of service rewards and invitations to recognition events
-   Monthly/yearly recognition schemes
-   Recognising personal milestones – new baby, wedding, birthdays and anniversaries
-   Retirement parties

**<u>CAREER GROWTH AND PROFESSIONAL ADVANCEMENT</u>**

**<u>HEALTH, WELLBEING AND SOCIAL IMPACT</u>**

**<u>RECOGNITION AND THE SOCIAL SCENE</u>**

_Marriott International is an equal opportunity employer. We believe in hiring a diverse workforce and sustaining an inclusive, people-first culture. We are committed to non-discrimination on any protected basis, such as disability and veteran status, or any other basis covered under applicable law._

Marriott Hotels strive to elevate the art of hospitality, innovating at every opportunity while keeping the comfort of the oh-so-familiar all around the globe. As a host with Marriott Hotels, you will help keep the promise of "Wonderful Hospitality. Always." by delivering thoughtful, heartfelt, forward-thinking service that upholds and builds upon this living legacy. With the name that's synonymous with hospitality the world over, we are proud to welcome you to explore a career with Marriott Hotels. In joining Marriott Hotels, you join a portfolio of brands with Marriott International. **Be** where you can do your best work, **begin** your purpose, **belong** to an amazing global team, and **become** the best version of you.

JW Marriott is part of Marriott International's luxury portfolio and consists of more than 100 beautiful properties in gateway cities and distinctive resort locations around the world. JW believes our associates come first. Because if you're happy, our guests will be happy. JW Marriott associates are confident, innovative, genuine, intuitive, and carry on the legacy of the brand's namesake and company founder, J.Willard Marriott. Our hotels offer a work experience unlike any other, where you'll be part of a community and enjoy true camaraderie with a diverse group of co-workers. JW creates opportunities for training, development, recognition and most importantly, a place where you can pursue your passions in a luxury environment with a focus on holistic well-being. Treating guests exceptionally starts with the way we take care of our associates. That's The JW Treatment. In joining JW Marriott, you join a portfolio of brands with Marriott International. **Be** where you can do your best work, **begin** your purpose, **belong** to an amazing global team, and **become** the best version of you.