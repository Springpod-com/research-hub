**The Courtyard by Marriott hotel Sandy Park**, Exeter is a Hotel which opened in 2022 and is uniquely positioned next to the Exeter Chiefs Rugby Stadium with 250 bedrooms. Whether you are a rugby fan or not – this is destination for talent spotting 

**The View**; A completely unique roof top restaurant & bar venue offering locally sourced fresh produce in Exeter. Distinctly visible from far distances and is synonymous with the service experience provided, it features elegant and spacious seating in a contemporary design.

**Kitchen & Bistro**; Located on our 3rd floor, this more relaxed dining option caterers for the business guests all day and offers simple dishes using the best local ingredients Devon has offer. 

As well as our 2 culinary offerings, we cater for meetings and events whilst hosting elite sports teams, along with bespoke celebrations. 

**YOUR EFFORTS, OUR APPRECIATION**

**Salrary From £36,000 - £40,000**

-   **£1,000 Joining bonus after 6 months Completion in the role**
-   **Meals** -  Complimentary Meals in our canteen.
-   **Private Medical -** Look after your wellbeing
-   **Life Insurance –** Protection for Loved Ones
-   **Bonus Scheme -** Yearly based on performance and KPIs
-   **Learning and Growing -** Access to the best digital and classroom based training resources and cross exposure opportunities
-   **Apprenticeships -** Opportunities to undertake an apprenticeship to support your development in your role.
-   **Holiday** - 23 days of holiday + public holidays (Increase over time)
-   **Uniform Provided -** Dry cleaning included.
-   **Company Enhanced Pension** **Scheme –** Save for your future.
-   **Take Care -** Access to our Take Care Emotional Wellbeing Resources & Associate Assistance Service
-   **Celebrate** \- Awards and Recognition Celebrations
-   **BenefitHub** - Access to further discounts for shopping, cinema tickets, technology and more!
-   **Long Service Recognition -** Dedicated appreciation events for when you reach career milestones within the company.
-   **Global Marriott Hotel Discounts –** Accessible to you and your loved ones, travel the world with Marriott International.
-   **Food & Beverage Discounts** - 20% Discount in all F&B outlets within Marriott Properties

As Our Hotel Sous Chef;

-   Have all-round expertise in casual dining 
-   Banqueting experience from 10 - 100, no 2 days are the same. 
-   Passionate about Fresh Local Ingredients
-   Have an understanding of food waste and a desire to use all the ingredient
-   Exhibit culinary talents by personally running the pass and producing all elements if the menu when required
-   Lead the staff and managing all food related functions for the the hotel
-   Work to continually improve guest and employee satisfaction
-   Be responsible for guiding and developing the Kitchen & Bistro team
-   Knowledge of Food Cost and ability to work to Margins
-   Experience in menu creation for various event styles
-   Flexible approach to working in all areas of the hotel (K&B, M&E, The View, Breakfast)
-   Supervise all kitchen areas to ensure a consistent, high quality product is produced
-   Ensure sanitation and food standards are achieved
-   Be responsible to oversee all food preparation and support all areas
-   Review staffing levels to ensure that guest service, operational needs and financial objectives are met

Join Marriott Bonvoy

Members receive complimentary Wi-Fi plus other exclusive benefits

EARN FREE NIGHTS    FREE WI-FI    MEMBER RATES    EXCLUSIVE OFFERS

> [_**Join for FREE**_](https://joinmarriottbonvoy.com/emeaqr/s/en-gb/ch/extcy) 

_At Marriott International, we are dedicated to being an equal opportunity employer, welcoming all and providing access to opportunity. We actively foster an environment where the unique backgrounds of our associates are valued and celebrated. Our greatest strength lies in the rich blend of culture, talent, and experiences of our associates. We are committed to non-discrimination on any protected basis, including disability, veteran status, or other basis protected by applicable law._

At Courtyard, we’re passionate about better serving the needs of travelers everywhere. It’s what inspired us to create the first hotel designed specifically for business travelers, and it’s why the Courtyard experience today empowers our guests, no matter the purpose of their trip. We’re looking for achievers who are passionate about providing a guest experience that goes above and beyond, enjoy being part of a small yet ambitious team, and love learning how to always improve – all while having fun.

In joining Courtyard, you join a portfolio of brands with Marriott International. **Be** where you can do your best work, **begin** your purpose, **belong** to an amazing global team, and **become** the best version of you.