# Executive Sous Chef (art'otel): Career Simulation Scripts

## Script 1: Career Overview

Ever wondered who keeps a hotel's kitchens running when the Executive Chef is in a meeting, on a day off, or in the middle of a five-hundred-cover banquet somewhere else in the building?

That's the Executive Sous Chef: second in command across every kitchen in the hotel, and the person the brigade actually turns to hour by hour.

Executive Sous Chefs run the day-to-day operation. They oversee the restaurant, banqueting, and room service outlets, lead the events kitchen, and step into the Executive Chef's shoes whenever they're needed.

They work alongside the Executive Chef on menus and budgets, handle ordering and the admin behind it, keep food safety standards where they need to be, and lead the drive to cut food waste across every outlet.

It's a role that blends craft with commercial thinking. You're still cooking and still on the pass, but you're also reading cost reports, checking stock, briefing the events team, and developing the Chefs de Partie who'll one day run their own sections.

From here, you could become an Executive Chef, a group or regional culinary lead, or move into food and beverage leadership across a hotel.

If you want a career where you lead from the kitchen floor, shape what a hotel serves, and grow into running the whole show, Executive Sous Chef could be the best next step for you.

## Script 2: Activity Brief

PART TITLE: Welcome

Welcome to your shift. You are the Executive Sous Chef of a Marriott hotel. The Executive Chef sets the direction, but today they're tied up in a regional planning meeting, so you're the one the outlets, the events team, and the stores are coming to when something needs steering or a call needs making.

Over the course of this activity, six real situations will land on your desk. Some are yours to decide. Some you'll need to take to the Executive Chef or another department. Knowing the difference is part of the job.

PART TITLE: Briefing summary

Your job is to keep every kitchen in the hotel running so that guests get great food, safely, on time, and at a cost the business can sustain. You oversee the restaurant, banqueting, and room service outlets. You lead the kitchen side of events. You support the Executive Chef on menus and budgets, you own ordering and the admin around it, and you lead the effort to reduce food waste. No two days look the same, and problems rarely arrive one at a time or at a convenient moment. In this activity, you'll work through six scenarios drawn from a typical week in the role. Each one asks you to weigh up the situation and decide what you'd do next.

PART TITLE: Contextualising the task

Being an Executive Sous Chef means constantly balancing competing priorities: food safety and compliance always come first, but guest experience, food cost, team wellbeing, and commercial targets are never far behind.

You're also balancing your position. You have real authority across the outlets, but the Executive Chef owns the final word on menus, budgets, and standards. Part of the skill is knowing when to act, when to recommend, and when to escalate.

Here are the six situations you'll be making calls on:

1. A conference organiser asks for a dietary change for three hundred guests two days before a gala dinner. The Executive Chef is unreachable until this evening, and the events team needs an answer by lunchtime.  
2. The weekly food cost report shows the restaurant outlet running well over target. The Executive Chef has asked you to find out why and bring them options before the finance meeting on Friday.  
3. An environmental health inspection is announced for tomorrow, and a walk-through of the room service kitchen shows temperature logs haven't been completed properly for four days.  
4. Your stores report shows you've been over-ordering fresh produce for banqueting, and the bins tell the same story. The general manager has asked the kitchen for a visible reduction in food waste this quarter.  
5. The Head Chef of the restaurant outlet calls in sick on the morning of a fully booked Saturday, and the events kitchen is running a three-hundred-cover wedding the same night.  
6. The Executive Chef is redesigning the restaurant menu and has asked you to propose three new dishes that use ingredients already on the ordering list, so the change doesn't add to the budget.

Each decision you make has knock-on effects, for guests, for colleagues, for the Executive Chef who'll answer for the kitchen, and for the hotel's reputation and running costs.

PART TITLE: Key tips

Safety and compliance come first, always, even when it's inconvenient. Think about the guest impact of every option, not just the numbers. Weigh up cost and time, but never let either one override standards. Know when a decision is yours to make and when it needs the Executive Chef, HR, finance, or the general manager involved, and when you do escalate, bring options, not just problems.

And keep communicating: your outlet teams, front of house, the events team, and the Executive Chef all need to know what's happening and when.

PART TITLE: Sign off

Executive Sous Chefs are the engine of a hotel kitchen. They turn the Executive Chef's vision into what actually gets served, and the decisions they make every shift affect guest safety, food waste, the reputation of the kitchen, and the hotel's bottom line.

Now it's your turn. Work through each scenario, weigh up your options, and make the calls a real Executive Sous Chef would have to make. Good luck.

## Script 3: Trailer

Have you ever wondered who keeps every kitchen in a hotel running, from the breakfast buffet to a banquet for five hundred, on the days the Executive Chef can't be everywhere at once?

That's where art'otel comes in: one of the world's leading hotel groups, sitting at the cutting edge of hospitality and food.

(PAUSE FOR MOTION GRAPHIC)

One career. Endless variety. Executive Sous Chefs are second in command across a hotel's kitchens, overseeing the outlets, running events, and keeping the whole operation on track.

(PAUSE FOR MOTION GRAPHIC)

From helping shape a new menu, to steering a brigade through a three-hundred-cover wedding, to cutting the waste that eats into a kitchen's budget, this is a career built on craft, leadership, and commercial thinking.

If you love food, want to lead people, and like the idea of being the one everyone turns to, this could be the career for you.

(PAUSE FOR MOTION GRAPHIC)

Learn about this and more in this Career Simulation, developed with culinary leaders at art'otel, giving you a real taste of what this career looks like today.

(PAUSE FOR MOTION GRAPHIC)

Powered by Springpod, this programme will show you what it really means to lead a hotel kitchen from the inside, and how the skills you build today could take you to the top.

## Script 4: Meet The Expert

Can you introduce yourself and tell us about your background and how you became an Executive Sous Chef?  
What does a typical day look like for you as an Executive Sous Chef?  
What are some of the most exciting or challenging projects you’ve worked on?  
What are the key skills that you use most frequently in your job, and how did you develop them?  
Where do you see the Executive Sous Chef field heading in the next 5-10 years?  
What advice would you give to someone considering becoming an Executive Sous Chef?