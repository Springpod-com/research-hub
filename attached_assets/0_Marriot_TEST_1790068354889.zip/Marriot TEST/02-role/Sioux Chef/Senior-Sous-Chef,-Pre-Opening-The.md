**Senior Sous Chef**

Coming soon to the heart of Mayfair, **The St. Regis** London marks the brand’s prestigious debut in the United Kingdom. This is a destination where history and modernity meet, where the energy of the city is palpable, and where every arrival feels personal. With signature butler service, refined interiors by Richmond International, and an unmatched Bond Street address, The St. Regis London embodies ‘Live Exquisite’ a celebration of London’s pioneering and glamorous lifestyle for the Luminaries of the world.

**Le Perroquet** 

**Le Perroquet** is an all-day French brasserie from Michelin-starred Chef Daniel Rose, offering classic French dishes crafted with seasonality, technique and a sense of occasion in the heart of Mayfair. It will open at The St. Regis London, Mayfair’s newest luxury destination, located at the corner of Conduit and New Bond Street.

We are seeking an exceptional **Sous Chef** to support the creation and delivery of an extraordinary culinary experience at The St. Regis London. This role is far more than operational support, it is a partnership opportunity for a culinary leader with refined technique, creative vision, and a passion for luxury gastronomy.

As **Executive Sous Chef,** you will work closely with the Executive Chef to oversee daily kitchen operations, guide and inspire the brigade, and ensure that every dish reflects the artistry, precision, and sophistication synonymous with the St. Regis brand. You will champion culinary excellence, uphold the highest standards of food quality and safety, and contribute to the development of innovative menus and presentations that elevate our dining experiences into moments of distinction.

**Key Responsibilities**

-   Support the Executive Sous Chef in shaping a refined and innovative culinary identity aligned with the St. Regis brand 
-   Lead daily kitchen operations, ensuring seamless service and adherence to brand and food safety standards 
-   Maintain exceptional food quality through rigorous monitoring of ingredients, preparation, and presentation 
-   Assist in menu development, culinary innovation, and the creation of artistic food displays
-   Oversee purchasing, receiving, storage, and inventory management to ensure quality and cost efficiency 
-   Ensure full compliance with food handling, sanitation, and UK health and safety regulations 
-   Manage staffing levels to meet operational needs and guest expectations 
-   Build strong, collaborative relationships within the culinary team and across departments 
-   Support other culinary and F&B operations to strengthen overall hotel performance 
-   Participate in departmental training, orientation, and performance management processes

**Core Competencies**

We are seeking a culinary leader with both technical mastery and creative ambition—someone who thrives in a luxury environment and understands the importance of precision, artistry, and guest‑centric service. This role is ideal for a Sous Chef who sees themselves as a partner in shaping the future of our culinary offering. You should have:

-   A strong background in high‑end culinary environments, ideally luxury hotels or fine dining 
-   Proven experience leading kitchen teams and supporting large‑scale operations 
-   A passion for delivering elevated, personalized guest experiences 
-   A commitment to excellence, creativity, and continuous improvement
-   The ability to inspire, mentor, and lead with confidence and grace

At **The St. Regis London**, our Hosts are the heartbeat of our legacy of exceptional service. In honour of your dedication, we offer a curated collection of benefits designed to support and elevate your journey with us.

_Financial Rewards_

-   Competitive salary designed to recognise excellence
-   Enhanced pension
-   Life assurance
-   Company sick pay
-   Additional holiday allowance
-   Access to BenefitHub's exclusive retail, wellness and travel privileges
-   Friends & Family preferred rates at Marriott hotels worldwide

_Career Development_

-   Clear pathway for internal promotions and transfers
-   Cross-department training to refine your craft and broaden your expertise
-   Expert-led development programmes
-   Continuous learning through structured programmes
-   Premium e-learning platform access
-   Be part of an exclusive pre-opening experience shaping the future of the property

_Wellbeing Support_

-   Private Medical Insurance
-   Employee Assistance Programme
-   Complimentary meals on duty, crafted with care and served in our staff restaurant featuring wholesome, quality cuisine.
-   Food & Beverage discounts across Marriott properties
-   Year-round wellbeing initiatives and wellness activities

_Recognition & Appreciation_

-   Award programmes celebrating exceptional performance
-   The Astor Awards
-   Distinctive Moments celebration
-   Long service awards
-   Key life moments celebrated – birthday, anniversaries, personal milestones and achievements
-   Vibrant social calendar with team events and engagement activities

_\*Terms and Conditions Apply_

_Eligibility_

In line with the requirements of the Asylum & Immigration Act 1996, all applicants must be eligible to live and work in the UK. Documented evidence of eligibility will be required from candidates as part of the recruitment process.

_At Marriott International, we are dedicated to being an equal opportunity employer, welcoming all and providing access to opportunity. We actively foster an environment where the unique backgrounds of our associates are valued and celebrated. Our greatest strength lies in the rich blend of culture, talent, and experiences of our associates. We are committed to non-discrimination on any protected basis, including disability, veteran status, or other basis protected by applicable law._

Combining timeless glamour with a vanguard spirit, St. Regis Hotels & Resorts is committed to delivering exquisite experiences at more than 50 luxury hotels and resorts in the best addresses around the world. Beginning with the debut of The St. Regis hotel in New York by John Jacob Astor IV at the dawn of the twentieth century, the brand has remained committed to an uncompromising level of bespoke and anticipatory service for all of its guests, delivered flawlessly by a team of gracious hosts that combine classic sophistication and modern sensibility, as well as our signature Butler Service. We invite you to explore careers at St. Regis. In joining St. Regis, you join a portfolio of brands with Marriott International. **Be** where you can do your best work, **begin** your purpose, **belong** to an amazing global team, and **become** the best version of you.