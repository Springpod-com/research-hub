  ![group of interns smiling](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/FZTJ0_early-careers-hero/early-careers-hero.jpg)

  ![Group of Marriott chef's tasting dishes in the kitchen](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/BWLRX_early-careers-1/early-careers-1.jpg)

## Early Career Programs

We have many opportunities worldwide for those early in their career. Many programs are detailed below as well as global direct placement and apprenticeships in our Europe and Asia Pacific regions.

**Programs and opportunities:**

-   Hotel Internship Program
-   Voyage Leadership Development Program
-   HQ Fellowship Program
-   Direct Placement Opportunities
-   Apprenticeships

## Hotel Internship Program

Learn first-hand about a hotel’s operations and find your true calling in the travel industry. The minimum duration of this paid program is 10 weeks.

**Business functions include:**

-   BUILD upon your classroom studies through our Hotel Internship Program
-   RECEIVE hands-on training at a Marriott managed hotel
-   GAIN real-world experience in hospitality management
-   EXPERIENCE the industry from the ground-up
-   GET IMMERSED in Marriott’s culture + business
-   WORK WITH AND LEARN from experts in the industry

[Find these Jobs](https://careers.marriott.com/career-journeys/early-careers/hotel-internship-program/jobs?keyword=%22intern%22)

  ![two men sitting at a table for a meeting, one in a suit and one in a chef's uniform](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/4C1D2_early-careers-2/early-careers-2.jpg)

  ![Maintence checking the pipes of a building](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/J3KPF_early-careers-5/early-careers-5.jpg)

## Voyage Leadership Development Program

Voyage is Marriott International’s post-graduate award-winning, global leadership development program. The duration of this paid program is 12-18 months and available in over 50 countries.

-   RECEIVE hands-on, discipline-specific training at a Marriott managed hotel
-   ACCESS leadership training through custom technology
-   NETWORK with colleagues globally through social collaboration tools
-   ENGAGE with senior Marriott executives
-   LEARN on the job with mini departmental rotations
-   PARTNER with coaches and champions who encourage your growth and keep you challenged

Successfully completing the program puts you on a path towards a management position that’s right for you.

[See All Opportunities](https://careers.marriott.com/career-journeys/early-careers/voyage-leadership-development-program/jobs?keyword=%22voyage%22)

## HQ Fellowship Program

The Marriott HQ Fellowship program provides undergraduate, graduate, MBA, and Law students the opportunity to connect with people through the power of travel. The program includes curated learning paths, career growth and development opportunities, informative programming with access to executives, and exposure to real business challenges faced by Marriott leaders. Participants are onboarded each summer at our headquarters in Bethesda, Maryland. Internship opportunities are sometimes available in regional offices as well.

Search for these opportunities on our site during the months of September-October.

[Find these Jobs](https://careers.marriott.com/career-journeys/early-careers/HQ-fellowship-Internship-program/jobs?keyword=HQFellows)

  ![three smiling young professionals](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/6J4CR_early-careers-4/early-careers-4.jpg)

  ![woman bartender shaking a beverage](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/AEG0A_early-careers-3/early-careers-3.jpg)

## Apprenticeships

Develop skills for your future! Launch your career with the #1 leader in hospitality with paid on-the-job training, the opportunity to discover your passions, all in an inclusive environment that supports your development and wellbeing. Upon successful completion of the program and armed with industry-recognized qualifications, you could enter a long-term career at Marriott. The opportunities are endless.

In Europe you will find these opportunities in Germany, France, and United Kingdom and in many countries in our Asia Pacific region.

[Search Opportunities](https://careers.marriott.com/career-journeys/early-careers/apprenticeships/jobs?keyword=%22apprentice%22)

## Hear from Our Early Career Associates

## Expansive Opportunities

30+

### Brands

9000+

### Hotels

140+

### Countries and Territories

## Let's Keep in Touch

Join our talent community for up-to-date job opportunities, company news, announcements, career tips and more!

[Sign Up Now](https://careers.marriott.com/career-journeys/early-careers/#)

  ![Man with spatula in kitchen](https://dokumfe7mps0i.cloudfront.net/oms/7527/image/2025/9/D5B1V_home-tc/home-tc.jpg)