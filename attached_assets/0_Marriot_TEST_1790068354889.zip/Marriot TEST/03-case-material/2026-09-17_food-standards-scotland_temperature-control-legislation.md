# Temperature control law — the review lines and limits

Source: Food Standards Scotland, "Guidance on Temperature Control Legislation in the United Kingdom"
Address: https://www.foodstandards.gov.scot/sites/default/files/migration/downloads/Guidance_on_temperature_control_legislation.pdf
Read: 2026-09-17 · Tier 3

Underpinning law: Regulation (EC) 852/2004 (general requirement for temperature control); The Food Safety and
Hygiene (England) Regulations 2013, Schedule 4; The Food Hygiene Regulations 2006 in Scotland, Wales and Northern
Ireland.

## Chill holding

- **8°C or below** for "foods which are likely to support the growth of pathogenic micro-organisms or the formation of toxins"
- Tolerance, England/Wales/NI: up to **4 hours** above 8°C for display for sale or service, one period only;
  up to **2 hours** for loading/unloading or other unavoidable practical reasons
- Scotland: no specified tolerance periods
- Note: 8°C is the legal limit. Industry practice is to set fridges at 5°C or below so that the legal limit is not
  breached on a door opening — confirm with the client what Marriott's own brand standard sets.

## Hot holding

- **63°C or above** for food "for service or on display for sale, that has been cooked or reheated"
- Tolerance, England/Wales/NI: up to **2 hours** below 63°C for service or display
- Scotland: reheated foods must be raised to **not less than 82°C**

## Cooling

The guidance requires cooling "as quickly as possible following the heat-processing stage"; paragraph 18 states
cooling "must be consistent with food safety". The commonly cited 90-minute cooling rule is industry guidance,
**not** stated in this document. If the storyboard uses 90 minutes, register it as tier 3 industry practice or
confirm it against Marriott's own food safety management system.

## For the fact register

Any reading, unit, review line or limit the chapter uses should come from this file or from the client. The three
that carry a case on their own: 8°C chilled, 63°C hot hold, 82°C reheat in Scotland.
